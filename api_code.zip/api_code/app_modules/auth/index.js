"use strict";
var app = require('@speridian/pankanis-app');
var router = app.expressRouter();
var config = require('config');
var passport = require('passport');
var cookieParser = require('cookie-parser');
var LocalStrategy = require('passport-local').Strategy;
var constants = require('../common/constants');
var co = require('co')
var foreach = require('co-foreach');
var _ = require('lodash');
var db = config.database;
var sessionStore = null;
var session = require('express-session');
var ActiveDirectory = require('activedirectory');
var ad = new ActiveDirectory(config.ldap);
var BasicStrategy = require('passport-http').BasicStrategy;
var dbmon = require('dbmon');

switch (db.client) {
    case 'pg': {
        var pg = require('pg');
        var pgSession = require('connect-pg-simple')(session);
        sessionStore = new pgSession(
            {
                pg: pg,                                  // Use global pg-module
                conString: `postgres://${db.user}:${db.password}@${db.host}/${db.databaseName}`, // Connect using something else than default DATABASE_URL env variable
                tableName: 'session'               // Use another table-name than the default "session" one
            })
        break;
    }
}

app.express.use(session({
    secret: 'secret',
    key: config.appCode + ".sid",
    store: sessionStore,
    cookie: {
        maxAge: 30 * 24 * 60 * 60 * 1000, // 30 days
        secure: false, path: '/'
    },
    resave: false,
    saveUninitialized: false,
}));

app.express.use(passport.initialize());
app.express.use(passport.session());


function autheticateAny(req, res, next) {
    /**
     * Temporary code for accessing session from cross domain
     * will need to remove after fixing with cookies in cross domain origin issuse with passport js
     *
     * If header have 'connect.id' then fetch user obejct from seeion table with parameter connect.sid
     * then save user object into req.user object ....
     */
    console.log("inside authenticate any function!");
    let apiResponse = app.modules.common.apiresponse;
    let message = app.modules.props.message;
    if (req.isAuthenticated()) {
        console.log("isAuthenticated is true");
        return next();
    } else if (req.headers['connect.sid']) {
        console.log("inside else if");
        //app.knex('session').select('sess').where('sid', req.headers['connect.sid']).then(data => {
        app.knex(db.session_info.table).select(db.session_info.col).where('sid', req.headers['connect.sid']).then(data => {
            console.log(data);
            if (!_.isEmpty(data)) {
                req.user = data[0][db.session_info.col].passport.user;
                return next();
            } else {
                res.json(
                    apiResponse.dataResponse(401, message.sessionInvalid, null)
                );
            }
        }).catch(err => {
            res.json(
                apiResponse.dataResponse(500, message.sessionError, null)
            );
        })
    } else {
        res.json(
            apiResponse.dataResponse(401, message.sessionInvalid, null)
        );
    }
}

// passport.serializeUser(function (userr, done) {
//     app.logger.info(`serializeUser ${JSON.stringify(userr)}`);
//     done(null, userr);
// });

// passport.deserializeUser(function (user, done) {

//     console.log(user);
//     app.knex('m_user')
//         .select()
//         .where('user_id', user.user_id)
//         .then(function (userResult) {
//             co(function* () {
//                 if (_.isEmpty(userResult))
//                     return done(null, false);

//                 return done(null, userResult[0]);
//             })
//                 .catch((err) => {
//                     return done(err)
//                 })
//         }).catch(err => {
//             return done(err)
//         });

// });

function authenticateUserFromDB(sessionId) {
    return app.knex(db.session_info.table).select(db.session_info.col).where('sid', sessionId)
}

app.express.use('/', router);

app.passport = passport;

module.exports = {
    autheticateAny,
    authenticateUserFromDB
}

app.logger.info("passport authentication module initialized");
