"use strict";
var app = require('@speridian/pankanis-app');
var co = require('co');
var _ = require('lodash');
var forEach = require('co-foreach')
var util = require('../utils/util');
var constants = require('../common/constants');


class BarcodeDal {
    constructor() { }
}

BarcodeDal.prototype.generateBarcode = (barcode, done) => {
    var knex = app.knex;
    co(function* () {
        let res = yield knex('barcodes')
            .insert(barcode)
        console.log(res);
        done(null, res);
    }).catch(err => {
        done(err, null);
    })
}

BarcodeDal.prototype.getBarcodes = (noOfBarcodes, done) => {
    var knex = app.knex;
    co(function* () {
        let res = yield knex.from('barcodes')
            .select('*')
            .limit(noOfBarcodes)
            .returning('*');
        // console.log(res);
        done(null, res);
    }).catch(err => {
        console.log(err);
        done(err, null)
    })
}

BarcodeDal.prototype.viewBarcodes = (status, noOfBarcodes, done) => {
    var knex = app.knex;
    console.log('inside dal');
    let query = knex.from('barcodes')
        .select('*')
    if (noOfBarcodes == undefined)
        noOfBarcodes = 100;
    if (status == "unused") {
        query.where('barcode_used', null);
    } else if (status == "used") {
        query.whereNot('barcode_used', null)
    }
    query.limit(noOfBarcodes);

    co(function* () {
        let res = yield query;
        console.log(res);
        done(null, res);

    }).catch(err => {
        done(err, null)
    })
}

BarcodeDal.prototype.changeStatus = (id, date, done) => {
    var knex = app.knex;
    co(function* () {
        let res = yield knex('barcodes')
            .where('id', id)
            .update('barcode_used', date)
        done(null);
    }).catch(err => {
        console.log(err);
        done(err)
    })
}

BarcodeDal.prototype.searchBarcodes = (body, done) => {
    var knex = app.knex;
    let query = knex('barcodes')
        .select('*')
        .where('id', '>', 0)

    console.log(!body.status && body.status !== undefined);
    if (!body.status && body.status !== undefined) {
        query.andWhere('barcode_used', null)
    } else if (body.status == true) {
        query.whereNot('barcode_used', null)
    }
    if (body.entity_type) {
        query.andWhere('entity_type', body.entity_type)
    }
    if (body.entity_id) {
        query.andWhere('entity_id', body.entity_id)
    }
    if (body.id) {
        query.andWhere('id', body.id)
    }

    query.limit(body.noOfBarcodes)
    co(function* () {
        let res = yield query;
        done(null, res);
    }).catch(err => {
        console.log(err);
        done(err, null);
    })
}

BarcodeDal.prototype.assignBarcodeToReport = (reportId, barcode, done) => {
    var knex = app.knex;
    // if (!exists(reportId)) {
    //     done(err, null);
    // }
    console.log("Report id in assignBarcodeToReport....", reportId)
    // exists(reportId, (err, res) => {
    //     if(err) throw err;
    //     console.log("************************",res);
    //     done(err, null)
    // })
    console.log("getting barocode by id.................")
    getBarcodeId(barcode, (err, r) => {
        if (err) throw err;
        co(function* () {
            let res = yield knex('barcode_assigned_to_report')
                .insert({
                    barcode_id: r[0].id,
                    returns_data_id: reportId
                })
            new BarcodeDal().changeStatus(r[0].id, util.getCurrentDate(), (res) => {
                if (err) throw err;
                console.log('updated barcodes table')
            })
            new BarcodeDal().updateReturnsTable(reportId, (err, res) => {
                if (err) throw err;
                console.log('updated returns table')
            })
            done(null, res);
        }).catch(err => {
            console.log(err);
            done(err, null)
        })
    })
}

BarcodeDal.prototype.updateReturnsTable = (reportId, done) => {
    co(function *() {
        let res = yield app.knex('_GET_FBA_FULFILLMENT_CUSTOMER_RETURNS_DATA_')
            .update({
                barcode_assigned: "true"
            })
            .where('id', reportId)
        done(null, res)
    }).catch(err => {
        console.log(e);
        done(err, null)
    })
}

function getBarcodeId(barcode, done) {
    var knex = app.knex;
    co(function* () {
        let r = yield knex('barcodes')
            .select('id')
            .where('value', barcode)
        console.log("got barcode id : ", r, " type: ", typeof (r))
        done(null, r);
    }).catch(err => {
        console.log(err);
        done(err, null)
    })
}
function exists(reportId, done) {
    var knex = app.knex;
    console.log("Report id in exists....", typeof(reportId))
    co(function* () {
        let r = yield knex('barcode_assigned_to_report')
            .where('returns_data_id', reportId)
            .select()
        console.log(r)
        // if (r == 1) {
        //     done(null, r)
        // }
        done(null, r)
    }).catch(err => {
        console.log(err);
        done(err, null)
    })
}

module.exports = BarcodeDal