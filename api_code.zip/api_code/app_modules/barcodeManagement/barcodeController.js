'use strict'
var app = require('@speridian/pankanis-app')
var router = app.expressRouter()
var config = require('config')
var auth = require('../auth')
var _ = require('lodash')
var BarcodeService = require('./barcodeService')
var barcodeService = new BarcodeService();
var apiResponse = require('../common/apiresponse')
var co = require('co');
app.express.use('/barcode', router)

router.get('/generateBarcode', auth.autheticateAny, (req, res) => {
    barcodeService.generate((err, code, mesg) => {
        if (err) {
            let response = apiResponse.dataResponse(code, mesg, null);
            res.json(response);
        } else {
            let response = apiResponse.dataResponse(code, mesg, null);
            res.json(response);
        }
    });
})

router.post('/getBarcodes', auth.autheticateAny, (req, res) => {
    console.log(req.body);
    var noOfBarcodes = req.body.noOfBarcodes;
    barcodeService.getBarcodes(noOfBarcodes, (err, code, mesg, data) => {
        if (err) {
            let response = apiResponse.dataResponse(code, mesg, null);
            res.json(response);
        } else {
            let response = apiResponse.dataResponse(code, mesg, data);
            res.json(response);
        }
    })
})

router.post('/viewBarcodes', (req, res) => {
    console.log(req.body);
    var status = req.body.status;
    var noOfBarcodes = req.body.noOfBarcodes;
    barcodeService.viewBarcodes(status, noOfBarcodes, (err, code, mesg, data) => {
        if (err) {
            let response = apiResponse.dataResponse(code, mesg, null);
            res.json(response);
        } else {
            for (var i = 0; i < data.length; i++) {
                data[i]._id = data[i].id;
                data[i].id = undefined;
            }

            let response = apiResponse.dataResponse(code, mesg, data);
            res.json(response);
        }
    })
})

router.post('/changeBarcodeStatus', (req, res) => {
    console.log(req.body);
    barcodeService.changeStatus(req.body, (err, code, mesg) => {
        if (err) {
            let response = apiResponse.dataResponse(code, mesg, null);
            res.json(response);
        } else {
            let response = apiResponse.dataResponse(code, mesg, null);
            res.json(response);
        }
    })
})

router.post('/searchBarcodes', (req, res) => {
    barcodeService.searchBarcodes(req.body, (err, code, mesg, data) => {
        if (err) {
            let response = apiResponse.dataResponse(code, mesg, null);
            res.json(response);
        } else {
            let response = apiResponse.dataResponse(code, mesg, data);
            res.send(response);
        }
    })
})

router.post('/changeStatusOfOneBarcode', (req, res) => {
    console.log(req.body);
    var data = {}
    if (req.body.status == "used") {
        data.used = [req.body.id]
        // data.unused = []
    } else if (req.body.status == "unused") {
        data.unused = [req.body.id]
        // data.used = []
    } else {
        let response = apiResponse.dataResponse(500, "Invalid status request made ", null);
        res.send(response)
    }
    console.log(data);
    barcodeService.changeStatus(data, (err, code, mesg) => {
        if (err) {
            let response = apiResponse.dataResponse(code, mesg, null);
            res.json(response);
        } else {
            let response = apiResponse.dataResponse(code, mesg, null);
            res.json(response);
        }
    })
})

router.post('/assignBarcodeToReport', (req, res) => {
    barcodeService.assignBarcodeToReport(req.body.returns_data_id, req.body.barcode, (err, code, mesg) => {
        if (err) {
            let response = apiResponse.dataResponse(code, mesg, null);
            res.json(response);
        } else {
            let response = apiResponse.dataResponse(code, mesg, null);
            res.json(response);
        }
    })
})