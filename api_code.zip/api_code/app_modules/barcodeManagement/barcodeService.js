"use strict";
var app = require('@speridian/pankanis-app');
var config = require('config');
var _ = require('lodash');
var co = require('co');
var BarcodeDal = require('./barcodeDal');
var message = require('../props/message');
var constants = require('../common/constants');
var barcodeDal = new BarcodeDal();
var auth = require('../auth');
var util = require('../utils/util');
const uuidv1 = require('uuid/v1');

class BarcodeService {
    constructor() { }
}

BarcodeService.prototype.generate = (handler) => {
    for (var i = 1; i <= 10; i++) {
        var str = uuidv1();
        str = str.split('-').join('');
        str = str.substring(0, 10);
        console.log(str);
        var barcode = {
            value: str,
            barcode_used: null,
            entity_type: null,
            entity_id: null
        }
        generateBarcode(barcode, (err, res) => {
            if (err) {
                handler(err, 500, "Error while generating barcodes");
            }
        })
    }
    handler(null, 200, "Barcodes generated and added to database")
}

function generateBarcode(barcode, handler) {
    console.log("inside individual");
    barcodeDal.generateBarcode(barcode, (err, res) => {
        if (err) {
            console.log(err);
            handler(err, null)
        } else {
            handler(null, res)
        }
    })
}

BarcodeService.prototype.getBarcodes = (noOfBarcodes, handler) => {
    barcodeDal.getBarcodes(noOfBarcodes, (err, res) => {
        if (err) {
            handler(err, 500, "Error while getting barcodes", null)
        } else {
            handler(null, 200, "Successfully fetched barcodes", res)
        }
    })
}

BarcodeService.prototype.viewBarcodes = (status, noOfBarcodes, handler) => {
    barcodeDal.viewBarcodes(status, noOfBarcodes, (err, res) => {
        if (err) {
            console.log(err);
            handler(err, 500, "Error while getting barcodes", null)
        } else {
            handler(null, 200, "Successfully fetched barcodes", res)
        }
    })
}

BarcodeService.prototype.changeStatus = (body, handler) => {
    let date = app.modules.utils.util.getCurrentDate();
    if (body.used) {
        for (var i = 0; i < body.used.length; i++) {
            barcodeDal.changeStatus(body.used[i], date, (err) => {
                if (err) {
                    console.log(err);
                    handler(err, 500, "Error while changing the status of barcodes")
                }
            })
        }
    }
    if (body.unused) {
        for (var i = 0; i < body.unused.length; i++) {
            barcodeDal.changeStatus(body.unused[i], null, (err) => {
                if (err) {
                    console.log(err);
                    handler(err, 500, "Error while changing the status of barcodes")
                }
            })
        }
    }
    handler(null, 200, "Successfully changed status of barcodes")
}

BarcodeService.prototype.searchBarcodes = (body, handler) => {
    console.log('in service ............')
    barcodeDal.searchBarcodes(body, (err, res) => {
        if (err) {
            console.log(err);
            handler(err, 500, "Error while getting barcodes", null)
        } else {
            console.log('in service success............')
            handler(null, 200, "Successfully fetched barcodes", res)
        }
    })
}

BarcodeService.prototype.assignBarcodeToReport = (reportId, barcode, handler) => {
    barcodeDal.assignBarcodeToReport(reportId, barcode, (err, res) => {
        if (err) {
            console.log(err);
            handler(err, 500, "Error while assigning barcodes", null)
        } else {
            handler(null, 200, "Successfully assigned barcode", res)
        }
    })
}

module.exports = BarcodeService