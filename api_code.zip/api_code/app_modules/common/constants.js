'user strict';

const enable ='e';

const disabled='d';

const removed='r';

const unapproved='u';

const pending='p';

const complete='c';

const android_platform='ANDROID' ;

const ios_platform='IOS';

const accessRoleType='role';

const accessGroupType ='group';

const ldap='l'



module.exports = Object.freeze({
    user :  {
            enable,
            disabled,
            removed,
            unapproved
        } ,
        
    password:
          {
             enable,
             disabled
          }   , 

    role:   {
            enable:1,
            disabled:0,
            removed:-1
            } ,

    group:  {
            enable :1,
            disabled:0,
            removed:-1
            } ,

    device: 
           {
            enable,
            disabled,
            removed,
            unapproved
           }  ,

    push: {
            pending,
            complete,
            platform:
                    {
                        android_platform,
                        ios_platform
                     }
          } ,
     accessType :{
             group :'group',
             role :'role' 
     }    , 
          
     login_type :{
                basic    : 'basic',
                google   : 'google',
                twitter  : 'twitter',
                facebook : 'facebook',
                ldap     : 'ldap',
                mobile   : 'mobile'
     }     
  
});

