"use strict";
class Response {
    constructor(code, message, error) {
        this.code = code;
        this.message = message;
        if (error != 'undefined')
            this.error = error;
    }
}

class ListResponse extends Response {
    constructor(code, message, items) {
        super(code, message);
        this.items = items;
    }
}
class DataResponse extends Response {
    constructor(code, message, data) {
        super(code, message);
        this.data = data;
    }
}

module.exports = {
    listResponse: function (code, message, items) {
        return new ListResponse(code, message, items);
    },
    dataResponse: function (code, message, data) {
        return new DataResponse(code, message, data);
    },
    errorResponse: function (code, message) {
        return new Response(code, message, true);
    }
}