"use strict";
var config = require('config');
var sha1 = require('sha1');
var _ = require('lodash');
var app = require('@speridian/pankanis-app');
var moment = require('moment');
var crypto = require('crypto');
const algorithm = 'aes-256-ctr';
const password = 'd6F3Efeq';

module.exports.encrypt = function (text) {
    return sha1(text + config.hashCodeSalt);
}

module.exports.addDays = function (theDate, days) {
    return new Date(theDate.getTime() + days * 24 * 60 * 60 * 1000);
}

module.exports.getCurrentDate = function () {
    return moment.utc(new Date()).toDate();
}
module.exports.getStringDate = function (date, format) {
    return dateFormat(date, format)

}

module.exports.getConfigValue = function (tenant_id, config_key) {
    app.logger.info('getConfigValue------------', tenant_id, config_key);
    var sysparamServ = new app.modules.sysparam.sysparamServ();
    return sysparamServ.getConfigValue(tenant_id, config_key);
}

module.exports.aesEncrypt = function (text) {
    var cipher = crypto.createCipher(algorithm, password)
    var crypted = cipher.update(text, 'utf8', 'hex')
    crypted += cipher.final('hex');
    return crypted;
}

module.exports.aesDecrypt = function (text) {
    var decipher = crypto.createDecipher(algorithm, password)
    var dec = decipher.update(text, 'hex', 'utf8')
    dec += decipher.final('utf8');
    return dec;
}

module.exports.getSeverBasedPath = function (additionalpath) {
    return encodeURI(config.host + additionalpath);
}

module.exports.getTimestamp = function (date) {
    return Math.round(new Date(date) / 1000);
}

module.exports.toTimeString = function (duration) {

    if (duration) {
        var milliseconds = parseInt((duration % 1000) / 100)
            , seconds = parseInt((duration / 1000) % 60)
            , minutes = parseInt((duration / (1000 * 60)) % 60)
            , hours = parseInt((duration / (1000 * 60 * 60)) % 24);

        hours = (hours < 10) ? "0" + hours : hours;
        minutes = (minutes < 10) ? "0" + minutes : minutes;
        seconds = (seconds < 10) ? "0" + seconds : seconds;

        return hours + ":" + minutes + ":" + seconds;
    } else return null


}



module.exports.walkDirectorySync = function (dir, filelist) {
    var fs = fs || require('fs')
    let files = fs.readdirSync(dir)
    filelist = filelist || []
    files.forEach(function (file) {
        let stat = fs.statSync(dir + file)
        if (stat.isDirectory()) {
            filelist = walkSync(dir + file + '/', filelist)
        } else {
            // let relativePath = path.relative(rootFolder, dir + '/' + file)
            // filelist.push({ size: stat["size"], path: relativePath, fileName: file })
            var obj = JSON.parse(fs.readFileSync(dir + '/' + file, 'utf8'))
            filelist.push(obj)
        }
    })

    return filelist
}
module.exports.convertUTCDateToLocalDate = function (date) {

    var newDate = new Date(date.getTime() + date.getTimezoneOffset() * 60 * 1000);
    var offset = date.getTimezoneOffset() / 60;
    var hours = date.getHours();

    newDate.setHours(hours - offset);

    return newDate;
}
module.exports.convertLocalDateToUTC = function (date) {

    return new Date(date.getTime() + date.getTimezoneOffset() * 60000);
}


module.exports.hhmmssToSeconds = function (str) {
    var arr = str.split(':').map(Number);
    return (arr[0] * 3600) + (arr[1] * 60) + arr[2];
};

module.exports.secondsToHHMMSS = function (seconds) {
    var hours = parseInt(seconds / 3600, 10),
        minutes = parseInt((seconds / 60) % 60, 10),
        seconds = parseInt(seconds % 3600 % 60, 10);
    return [hours, minutes, seconds].map(function (i) { return i.toString().length === 2 ? i : '0' + i; }).join(':');
}

module.exports.getDates = function (startDate, endDate) {
    var dateArray = [];
    var currentDate = moment(new Date(startDate));
    var endDate = moment(new Date(endDate));
    while (currentDate <= endDate) {
        dateArray.push(moment(currentDate).format('YYYY-MM-DD'))
        currentDate = moment(currentDate).add(1, 'days');
    }
    return dateArray;
}

module.exports.getMinutes = function (firstDatetime, lastDatetime) {
    if (lastDatetime && firstDatetime)
        return Math.round((lastDatetime.getTime() - firstDatetime.getTime()) / 60000)
}

module.exports.capitalize = function (input) {
    return new String(input).replace(/^./, function (match) {
        return match.toUpperCase();
    });
}