
var app = require('@speridian/pankanis-app');
var router = app.expressRouter();
var config = require('config');
var auth = require('../auth');
let _ = require('lodash');
var RoleService = require('./roleService');
var apiResponse = require('../common/apiresponse');
var appCodes = require('../props/appCodes');
let roleService = new RoleService();

app.express.use('/roleManagement', router);

router.post('/add', auth.autheticateAny, (req, res) => {
    req.body.created_by = req.user.userarr[0].name;
    roleService.addRole(req.body, (err, code, mesg, data) => {
        let response = apiResponse.dataResponse(code, mesg, data);
        res.json(response);
    })
}) 

// req.body.updated_by = req.user.user_id;

router.post('/update', auth.autheticateAny, (req, res) => {
    console.log('inside update route................');
    req.body.updated_by = req.user.userarr[0].name;
    roleService.updateRole(req.body, (err, code, mesg, data) => {
        let response = apiResponse.dataResponse(code, mesg, data);
        res.json(response);
    })
})

router.get('/delete/:role_id', auth.autheticateAny, (req, res) => {
    roleService.deleteRole(req.params.role_id, (err, code, mesg) => {
        let response = apiResponse.dataResponse(code, mesg);
        if (!res.headersSent)
            res.json(response);
    })
})

router.get('/allRoles', auth.autheticateAny, (req, res) => {
    roleService.getAllRoles().then(data => {
        res.send(apiResponse.dataResponse(200, "successfully fetched ", data));
    }).catch(err => {
        res.send(apiResponse.dataResponse(500, "failed to fetche", err.message))
    });
})