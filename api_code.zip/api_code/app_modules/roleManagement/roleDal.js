"use strict";
var app = require('@speridian/pankanis-app');
var co = require('co');
var _ = require('lodash');
var forEach = require('co-foreach');
var joinjs = require('join-js').default;

class RoleDal {
    constructor() {
    }
}

RoleDal.prototype.getRoleByName = (roleName) => {
    return app.knex('m_role').select().where('role_name', roleName);
}

RoleDal.prototype.getRoleById = (role_id) => {
    return app.knex('m_role').select().where('role_id', role_id);
}

RoleDal.prototype.addRoleInDb = (data, handler) => {
    console.log("inside add role function");
    console.log(data);
    let roleData = data.role;
    roleData.updated_by = roleData.created_by;
    console.log(roleData);
    let knex = app.knex;
    let role_id;
    co(function* () {
        return knex.transaction(co.wrap(function* (trx) {
            app.logger.info("stating saving role");
            let role = yield knex('m_role').transacting(trx).insert(roleData).returning('role_id');
            console.log('.................');
            console.log(role);
            role_id = role;
            return role;
        }));
    }).then(trx => {
        trx.commit;
        handler(null, role_id);
    }).catch((trx) => {
        trx.rollback;
        handler(new Error(trx.err), {});
    })
}

RoleDal.prototype.updateRoleInDb = (data, handler) => {
    let roleData = data.role;
    let knex = app.knex;
    co(function* () {
        return knex.transaction(co.wrap(function* (trx) {
            app.logger.info("stating saving role");
            let role = yield knex('m_role').transacting(trx).update(roleData).where('role_id', roleData.role_id).returning('role_id');
            
            return trx;
        }));
    }).then(trx => {
        trx.commit;
        handler(null, { success: true });
    }).catch((trx) => {
        trx.rollback;
        handler(new Error(trx.err), {});
    })
}

RoleDal.prototype.deleteById = (role_id) => {
    var knex = app.knex;
    return knex('m_role').where('role_id', role_id)
                         .del()
                         .returning('role_id');
}

RoleDal.prototype.getAllRoles = () => {
    var knex = app.knex;
    return knex.select()
               .from('m_role')
               .returning('*')
}

module.exports = RoleDal;