"use strict";
var app = require('@speridian/pankanis-app');
var _ = require('lodash');
var co = require('co');
var RoleDal = require('./roleDal');
var util = require('../utils/util');
var message = require('../props/message');
var config = require('config');
let forEach = require('co-foreach');
var constants = require('../common/constants');
var HashMap = require('hashmap');
var roleDal = new RoleDal();

class RoleService {
    constructor() {
    }
}

RoleService.prototype.addRole = (body, handler) => {
    body.updated_by = body.created_by;
    let role = body;
    console.log("inside addrole service function");
    let date = util.getCurrentDate();
    co(function* () {
        let roleCheck = yield roleDal.getRoleByName(body.role_name);
        console.log(roleCheck);
        if (!_.isEmpty(roleCheck)) {
            handler(null, 401, message.roleAlreadyAdded)
        } else {
            console.log("in else");
            role.created_on = date;
            role.updated_on = date;
            role.created_by = body.created_by;
            role.updated_by = body.updated_by;
            role.status = body.status;
            var data = new Object();
            data.role = role;
            console.log("data");
            console.log("calling dal function");
            let success = roleDal.addRoleInDb(data, (err, rs) => {
                console.log('************');
                console.log(rs);
                if (err) {
                    app.logger.error("error while adding role  %s", JSON.stringify(err.message));
                    handler(null, 500, message.addroleFailed, null);
                } else {
                    data.role.role_id = rs[0];
                    handler(null, 200, message.addRoleSuccess, data.role);
                }
            });
        }
    }).catch(err => {
        app.logger.error("error while adding role  %s", JSON.stringify(err.message));
        handler(null, 500, message.addroleFailed);
    })
}

RoleService.prototype.updateRole = (body, handler) => {
    let role = body;
    let date = util.getCurrentDate();
    co(function* () {
        let roleCheck = yield roleDal.getRoleById(role.role_id);
        if (_.isEmpty(roleCheck)) {
            handler(null, 404, message.roleNotExists)
        } else {
            // let roleCheck = yield roleDal.getRoleByName(body.role_name);
            // console.log(roleCheck);
            // if (!_.isEmpty(roleCheck)) {
            //     handler(null, 401, message.roleAlreadyAdded)
            // } else {
            role.updated_on = date;
            role.updated_by = body.updated_by;
            role.status = body.status;
            var data = new Object();
            data.role = role;
            let success = roleDal.updateRoleInDb(data, (err, rs) => {
                if (err) {
                    app.logger.error("error while adding role  %s", JSON.stringify(err.messagerr));
                    handler(null, 500, message.updateroleFailed, null);
                } else {
                    co(function* () {
                        let res = yield app.knex.select('created_by', 'created_on').from('m_role').where('role_id', data.role.role_id).returning("*");
                        data.role.created_by = res[0].created_by;
                        data.role.created_on = res[0].created_on;
                        handler(null, 200, message.updateRoleSuccess, data.role);
                    })
                }
            });

        }
    }).catch(err => {
        app.logger.error("error while adding role  %s", JSON.stringify(err.message));
        handler(null, 500, message.updateroleFailed);
    })
}

RoleService.prototype.deleteRole = (role_id, handler) => {
    let date = util.getCurrentDate();
    co(function* () {
        let roleCheck = yield roleDal.deleteById(role_id);
        handler(null, 200, message.deleteRoleSuccess);
    }).catch(err => {
        app.logger.error("error while adding role  %s", JSON.stringify(err.message));
        handler(null, 500, message.deleteroleFailed);
    })
}

RoleService.prototype.getAllRoles = () => {
    return roleDal.getAllRoles();
}

module.exports = RoleService;