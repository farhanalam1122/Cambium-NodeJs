"use strict";
var app = require('@speridian/pankanis-app');
var co = require('co');
var _ = require('lodash');
var forEach = require('co-foreach')
var util = require('../utils/util');
var constants = require('../common/constants');

class UserDal {
    constructor() {
    }
}

UserDal.prototype.getUserByName = (username) => {
    return app.knex('m_user').select().where('name', username).returning('name');
}

UserDal.prototype.add = (user, handler) => {
    var knex = app.knex;

    var userData = {
        name: user.username,
        fname: user.fname,
        lname: user.lname,
        email_id: user.email_id,
        mobile_no: user.mobile_no,
        password: user.password,
        created_on: user.created_on,
        created_by: user.created_by,
        updated_on: user.updated_on,
        updated_by: user.updated_by,
        status: user.status
    }
    console.log(userData);
    co(function* () {
        return knex.transaction(co.wrap(function* (trx) {
            
            let userid = yield knex('m_user').transacting(trx).insert(userData).returning('user_id');
            console.log("logging userid");
            console.log(userid);
            user.user_id = userid[0];
            console.log('user added ',userid[0])
            app.logger.info("user  saved obejcet with id", userid[0]);

            return trx;
        }));
    }).then((trx) => {
        trx.commit;
        handler(null, { ok: true });
    }).catch((trx) => {
        trx.rollback;
        handler(new Error('User registration Failed'), null);
    })
}

UserDal.prototype.updateUserBYUserid = (user) => {
    var knex = app.knex
    var userData = user.userInfo;
    return new Promise(function (res, rej) {
        co(function* () {
            return knex.transaction(co.wrap(function* (trx) {
                let resuserData = yield knex('m_user').transacting(trx).where('user_id', user.user_id).update(userData).returning('*');
                console.log("********");
                console.log(resuserData);

                return resuserData;
            }));
        }).then((trx) => {
            trx.commit;
            res({ success: true })
        }).catch((trx) => {
            trx.rollback;
            rej(trx)
        })
    })
}

UserDal.prototype.delete = (user_id, status) => {
    var knex = app.knex;
    return knex('m_user').where('user_id', user_id)
                         .del()
                         .returning('user_id');
};

UserDal.prototype.userInfo = (userId, handler) => {
    return app.knex.select('user_id', 'name', 'fname', 'lname', 'updated_by', 'created_by', 'updated_on', 'created_on', 'email_id', 'mobile_no', 'status').from('m_user').where('user_id', userId).returning('*')
}

UserDal.prototype.getOldPasswordById = (userId) => {
    return app.knex.select('password').from('m_user').where('user_id', userId).returning('password')
}

UserDal.prototype.getUsers = (data) => {
    console.log("dal");
//    return app.knex.select().from('m_user').returning('*')
    return app.knex.select('user_id', 'name', 'fname', 'lname', 'updated_by', 'created_by', 'updated_on', 'created_on', 'email_id', 'mobile_no', 'status').from('m_user').returning('*')
}

UserDal.prototype.getUserBYEmail = (email, handler) => {
    app.knex('m_user')
        .select('*')
        .where('email_id', email)
        .then(function (user) {
            handler(null, user);
        }).catch(err => {
            handler(err, {});
        });
}
module.exports = UserDal