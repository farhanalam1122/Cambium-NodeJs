'use strict'
var app = require('@speridian/pankanis-app')
var router = app.expressRouter()
var config = require('config')
var auth = require('../auth')
var _ = require('lodash')
var UserService = require('./userService')
var apiResponse = require('../common/apiresponse')
var appCodes = require('../props/appCodes')
var userServ = new UserService();
var co = require('co');
app.express.use('/', router)
var UserDal = require('./userDal');
var userDal = new UserDal();

  router.post('/add',
   auth.autheticateAny,
    function (req, res) {
      var knex = app.knex;
      console.log("Printing req.user  ...............................")
      console.log(req.user.userarr[0].name);

      console.log("Printed req.user  ...............................")
      req.body.created_by = req.user.userarr[0].name;

      userServ.addUser(req.body, (err, code, mesg, data) => {
        if (err) {
          app.logger.error(`Failed to add user ${JSON.stringify(req.body)} \n  caused by error  ${err.message}`);
          res.json(apiResponse.errorResponse(500, err.message));
        } else{
          let response = apiResponse.dataResponse(code, mesg);
          response.user = data; 
          // {
          //   "data": ,
          //   "user": data
          // }
          if(!res.headersSent)
            res.status(200).send(response);
            // res.send(data);
        }
      }) 
  });

  router.post('/update', auth.autheticateAny,
  (req, res) => {
    console.log("update ...............")
    console.log(req.user.name);
    req.body.updated_by = req.user.name;
    userServ.modifyUser(req.body, (err, code, mesg, user) => {
      if(err) {
        let response = apiResponse.dataResponse(code, mesg, null);
        res.json(response);
      }
      let response = apiResponse.dataResponse(code, mesg, user);
      res.json(response);
    });
  });

router.post('/delete', auth.autheticateAny,
 (req, res) => {
    userServ.deleteUser(req.body.user_id, (err, code, mesg) => {
    res.send(apiResponse.dataResponse(code, mesg, null))
  })
});

router.get('/allUsers',
 auth.autheticateAny,
  function(req, res, next) {

  userServ.getUsersList(req.body, (err, items) => {
    if (err) {
      res.send("someting went wrong");
    } else {
      res.status(200).send(items);
    }
  })
});

router.get('/getUserInfo/:id', auth.autheticateAny, function(req, res, next) {
  var userId = req.params.id;
  console.log(userId);
  userServ.getUserById(userId, (err, code, mesg, user) => {
    res.send(user)
  });
})