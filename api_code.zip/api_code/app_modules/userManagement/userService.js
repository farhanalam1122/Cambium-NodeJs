"use strict";
var app = require('@speridian/pankanis-app');
var config = require('config');
var _ = require('lodash');
var co = require('co');
var UserDal = require('./userDal');
var message = require('../props/message');
var constants = require('../common/constants');
var userDal = new UserDal();
var auth = require('../auth');
var util = require('../utils/util');

class UserService {
    constructor() {
    }
}


UserService.prototype.addUser = (user, done) => {
    var authDal = app.modules.authentication.authenticationDAL;
    var userLogins = new Object();
    var currentDate = util.getCurrentDate();
    user.status = user.status;
    user.username = user.name;
    user.fname = user.fname;
    user.lname = user.lname;
    user.email = user.email_id;
    userLogins.hash_code = util.encrypt(user.password);
    user.password = util.encrypt(user.password);
    user.mobile = user.mobile_no;
    userLogins.created_by = user.created_by;
    user.updated_by = userLogins.updated_by = user.created_by;
    user.created_on = userLogins.updated_on = currentDate;
    user.updated_on = userLogins.created_on = currentDate;

    console.log(user);
    // co(function* () {
    //     let exists = yield userDal.getUserByName(user.username);
    //     console.log(exists);
    //     if (_.isEmpty(exists)) {
    //         done(null, 500 , "Such a user already exists");
    //     }
    // })
    
    app.logger.info("Adding user %s", JSON.stringify(user));

    userDal.add(user, (err, row) => {
        if (err) {
            done(err); 
        } else {
            co(function* () {
                app.logger.info(`User added successfully in system with user id ${user.user_id}`);
                done(null, 200, 'Successfully added user.', user);
            })
        }
    })
}

UserService.prototype.modifyUser = (user, handler) => {

    console.log(user);
    let currentDate = util.getCurrentDate();
    user.updated_on = currentDate;
    var pass = util.encrypt(user.password);
    user.userInfo = {
        email_id: user.email_id,
        mobile_no: user.mobile_no,
        fname: user.fname,
        lname: user.lname,
        password: pass,
        status: user.status,
        updated_on: currentDate,
        updated_by: user.updated_by,
        name: user.name,
    };

    co(function* () {
        console.log('here');
        let u = yield userDal.updateUserBYUserid(user);
        console.log(".......");
        console.log(u);
        delete user.password;
        delete user.userInfo.password;
        user.userInfo.user_id = user.user_id;
        delete user.userInfo;

        co(function* () {
            let res = yield app.knex.select('created_by', 'created_on').from('m_user').where('user_id', user.user_id).returning("*");
            user.created_by = res[0].created_by;
            user.created_on = res[0].created_on;
            console.log(user)
            console.log(res)
            handler(null, 200, message.updateUserSucces, user);
        }).catch(err => {
            app.logger.error(`errror while updating user `)
            handler(err, 500, message.updateUserFailed, user)
        })

        
    }).catch(err => {
        app.logger.error(`errror while updating user `)
        handler(err, 500, message.updateUserFailed, user)
    })
}

UserService.prototype.getUsersList = (data, handler) => {
    let userList = [];
    co(function* () {
        console.log("service");
        let userList = yield userDal.getUsers(data, handler);
        // console.log(userList);
        handler(null, userList);
    }).catch((err) => {
        handler(err, null);
    })
}

UserService.prototype.deleteUser = (userId, handler) => {
    co(function* () {
        let login_id = yield userDal.delete(userId);
        console.log(login_id);
        handler(null, 200, message.deleteUserSuccess)
    }).catch(err => {
        app.logger.error("error while delete  a user  caused by  ", JSON.stringify(userId), JSON.stringify(err));
        handler(err, 500, message.deleteUserfailed)
    });
}


UserService.prototype.getUserById = (userId, handler) => {
    co(function* () {
        let users = yield userDal.userInfo(userId, handler);
        console.log("here");
        console.log(users);
        handler(null, 200, "Success", users)
    }).catch(err => {
        app.logger.error("error while getting  a user  caused by  ", JSON.stringify(userId), JSON.stringify(err));
        handler(err, 500, "Error", null)
    });
}

UserService.prototype.getUserBYEmail = (email, result) => {
    console.log('userServ ----------')
    userDal.getUserBYEmail(email, result);
}

module.exports = UserService