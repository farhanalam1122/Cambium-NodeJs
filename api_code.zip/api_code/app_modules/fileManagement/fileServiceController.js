"use strict";
var app = require('@speridian/pankanis-app');
var router = app.expressRouter();
var config = require('config');
var auth = require('../auth');
let _ = require('lodash');
var fs = require("fs");
var mime = require('mime');
var path = require('path');
var mkdirp = require('mkdirp');
var util = require('util');
var FileService = require('./fileService');
app.express.use(config.v1apiBase, router);

router.get("/download/fs/*", function (request, response) {
  var filePath = `${config.uploadFileLocation}/${request.params[0]}`;
  var filename = path.basename(filePath);
  var mimetype = mime.lookup(filePath);

  response.setHeader('Content-type', mimetype);
  fs.stat(filePath, function (err, stat) {
    if (err) {
      response.send({ code: 200, message: `${filename} does not exists!` });
    } else {
      let view = false;
      if (request.query.view) {
        view = JSON.parse(request.query.view);
      }
      if (view) {
        response.setHeader('Content-disposition', 'inline; filename=' + filename);
      } else {
        response.setHeader('Content-disposition', 'attachment; filename=' + filename);
      }
      let dateStr = request.get('If-Modified-Since');
      if (dateStr) {
        var mtime = new Date(util.inspect(stat.mtime));
        var inputtime = new Date(util.inspect(dateStr));
        /*CR
        cant mix JSON response and file data in one 
        if no changes are there use HTTP status 304 .. pls look at HTTP RFC 
        */
        //comments   If-Modified-Since is getting fetched from header (and its optional), as we have done it for FileService in Java 
        if (mtime.toUTCString() == inputtime.toUTCString()) {
          response.send({ code: 304, message: `No changes done in in ${filename} !` });
        } else {
          var filestream = fs.createReadStream(filePath);
          filestream.pipe(response);
        }
      } else {
        var filestream = fs.createReadStream(filePath);
        filestream.pipe(response);
      }
    }
  });
});

router.post("/fs/csv/dump/:table_name", function (req, res) {
  let fileTobeUploaded = req.files.file;
  var path = require('path').join(`${config.uploadFileLocation}`, 'temp_files/csv/', `${fileTobeUploaded.name}`);
  
  if (!req.params.table_name) {
    res.send({ code: 406, message: 'Table name can not be null value.' })
  } else {
    var getDirName = path.dirname;

    var getDirName = require('path').dirname;

    // creates parent directory, if not exists 
    mkdirp(getDirName(path), function (err) {
      // uploads the file in respective location
      fileTobeUploaded.mv(path, function (err) {
        if (err) {
          res.send({ code: 500, message: 'File upload Failed!' });
        } else {
          var filestream = fs.readFileSync(path, { encoding: 'utf8' });
          new FileService().dumpCsv(filestream, { tbName: req.params.table_name }).then(data => {
            fs.unlinkSync(path);
            res.send(data);
          })
        }
      });
    });
  }
});

router.post('/upload/fs/*', function (req, res) {
  let path = `${config.uploadFileLocation}/images/${req.params[0]}`;
  var parsePath = require('path').parse(path);
  app.logger.info('Upload file called')
  mkdirp(parsePath.dir, function (err) {
    req.pipe(fs.createWriteStream(path))
      .on('finish', function (reponse) {
        res.send({ code: 200, message: 'File uploaded successfully!' });
      })
      .on('error', function (err) {
        app.logger.error("Error while uploadinf file at :%s /n caused by : %s ", path, err.stack);
        res.send({ code: 500, message: 'File upload Failed!' });
      });
  });
})

router.get('/fs/content/*', function (req, res) {
  var filePath = `${config.uploadFileLocation}/${req.params[0]}`;
  var filename = path.basename(filePath);
  var mimetype = mime.lookup(filePath);
  try {
    res.setHeader('Content-type', mimetype);
    new FileService().getReadStream(filePath, req.get('If-Modified-Since'), function (err, stream) {
      if (err) {
        res.send("Error while getting document ").status(500);
      } else if (stream != undefined) {
        let view = false;
        if (req.query.view) {
          view = JSON.parse(req.query.view);
        }
        if (view) {
          res.setHeader('Content-disposition', 'inline; filename=' + filename);
        } else {
          res.setHeader('Content-disposition', 'attachment; filename=' + filename);
        }
        stream.pipe(res);
      }
      else {
        res.send("Document not found").status(404);
      }

    })
  } catch (err) {
    app.logger.error("Error while downloading file caused by  ", filePath, err.stack);
    res.send("Falied to download ").status(500);
  }
});

router.post('/fs/content/*', function (req, res) {
  let path = `${config.uploadFileLocation}/${req.params[0]}`;
  new FileService().getWriteStream(path, function (err, stream) {
    if (err) {
      res.send("Error while uploadin document ").status(500);
    } else {
      req.pipe(stream)
        .on('finish', function (reponse) {
          res.send({ code: 200, message: 'File uploaded successfully!' }).status(200);
        })
        .on('error', function (err) {
          app.logger.error("Error while uploadinf file at :%s /n caused by : %s ", path, err.stack);
          res.send({ code: 500, message: 'File upload Failed!' }).status(500);
        });
    }
  });
});