"use strict";
var app = require('@speridian/pankanis-app');
var csvjson = require('csvjson');
var co = require('co');
var mime = require('mime');
var path = require('path');
var mkdirp = require('mkdirp');
var fs = require('fs');
var util = require('util');
class FileService {


}

FileService.prototype.dumpCsv = function (fileStream, opt) {
    return new Promise(function (res, rej) {
        co(function* () {

            var tbName = opt.tbName;
            var jsonObject = yield csvjson.toObject(fileStream, {
                delimiter: ',',
                quote: ''
            })
            console.log(jsonObject)
            var exists = yield app.knex.schema.hasTable(`${tbName}`);
            if (!exists) {
                rej(`No such ${tbName} table found`)
            } else {
                let data = yield app.knex.insert(`${tbName}`, jsonObject)
                res(true);
            }
        }).catch(function (err) {
            app.logger.error("error while saving csv  %s", JSON.stringify(err.message));
            rej(err)
        });
    })
}

FileService.prototype.getReadStream = (filePath, dateModified, done) => {
    fs.stat(filePath, function (err, stat) {
        if (err) {
            done(err, undefined);
        } else {
            ;
            if (dateModified) {
                var mtime = new Date(util.inspect(stat.mtime));
                var inputtime = new Date(util.inspect(dateModified));

                if (mtime.toUTCString() == inputtime.toUTCString()) {
                    done(null, undefined);
                } else {
                    done(null, fs.createReadStream(filePath));
                }
            } else {
                done(null, fs.createReadStream(filePath));
            }
        }
    });
}


FileService.prototype.getWriteStream = (path, done) => {
    var parsePath = require('path').parse(path);

    mkdirp(parsePath.dir, function (err) {
        if (err) done(err)
        else
            done(null, fs.createWriteStream(path))

    });
}

module.exports = FileService;