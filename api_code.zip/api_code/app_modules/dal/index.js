"use strict";
var config = require("config");
var app = require('@speridian/pankanis-app');

var knex = require('knex')({
  client: config.database.client,
  connection: {
    host: config.database.host,
    user: config.database.user,
    password: config.database.password,
    database: config.database.databaseName
  }
});
console.log("in database acces logic");

app.knex = knex;

app.knex
  .on('query', function (data) {
     
      app.logger.debug(`Query called at  :${new Date()} Query FORMED  : ${data.sql}  and PARAMETER bindings : ${data.bindings}`);
  })
  .on('query-error', function (error, obj) {
    app.logger.error(`Error whiile exceuting query caused by ${error.message} And stack trace ${error.stack}`);
  })