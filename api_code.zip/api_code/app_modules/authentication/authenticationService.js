"use strict";
var app = require('@speridian/pankanis-app');
var _ = require("lodash");
var restRequest = require('request');
var config = require('config');
var forEach = require('co-foreach');
var co = require('co');
var constants = require('../common/constants');
var authDal = require('./authenticationDal');
var message = require('../props/message');
var emailService = require('../emailsManagement/emailService');
var Email = require('../emailsManagement/email');


class AuthenticationService {
    constructor() {
    }
}

function getOldPassword(userId) {
    return app.knex.select('password').from('m_user').where('user_id', userId).returning('*');
    // return app.knex.select('user_id', 'name', 'fname', 'lname', 'updated_by', 'created_by', 'updated_on', 'created_on', 'email_id', 'mobile_no', 'status').from('m_user').returning('*')

}

AuthenticationService.prototype.getOldPasswordById = (userId, handler) => {
    let userDal = new app.modules.userManagement.userDal();
    co(function* () {
        let pass = yield userDal.getOldPasswordById(req.body.user_id);
        console.log(pass);
        handler(pass);
    }).catch(err => {
        app.logger.error("error while getting  password  caused by  ", JSON.stringify(userId), JSON.stringify(err));
        handler(null);
    });
}

// AuthenticationService.prototype.changePass = (req, pass, handler) => {
//     let util = app.modules.utils.util;
    
//     if (util.encrypt(req.body.oldPassword) != pass) {
//         handler(401, "Invalid old passord");
//     } else {
//         var newPassword = util.encrypt(req.body.newPassword);
//         var password = {
//             created_by: req.user.user_id,
//             newPassword: newPassword,
//             user_id: req.body.user_id
//         }

//         authDal.changeUserPass(password, (err, res) => {
//             if (err) {
//                 handler(500, 'Something went wrong while changing passord');
//                 app.logger.error("error while changing user passord caused by    %s", err);
//             }
//             else {
//                 handler(200, message.changePassTRUE);


                // new app.modules.model.notification.Notification( req.user.user_id			
                // ,"changed passord"		
                // ,"CHANGE_PASS"			
                // ,"You have changed password on  "					
                // ,''			
                // ,'').add();
                // let email = Email.setEmail
                //     (req.user.tenant_id,
                //     req.user.login_id,
                //     message.changePwdSubject,
                //     'change_pwd',
                //     req.user,
                //     "",
                //     "")
                // emailService.sendMail(email);



//             }
//         });
//     }
// }

AuthenticationService.prototype.saveBarcode = (body, handler) => {
        authDal.saveBarcode(body, (err, entry) => {
            if(err) {
                handler(err, 500, "Barcode already added", null)
            } else {
                handler(null, 200, "Successfully saved Barcode", entry)
            }
        });
}

AuthenticationService.prototype.getAllBarcodes = (handler) => {
    co(function* () {
        authDal.getAllBarcodes((entries) => {
            handler(null, 200, "Success", entries);
        })
    }).catch(err => {
        app.logger.error(`errror while fetching entries `)
        handler(err, 500, "Error while fetching all Barcodes", null)
    })
}

AuthenticationService.prototype.changePass = (req, handler) => {
    let util = app.modules.utils.util;
    console.log(req.user);
    if (util.encrypt(req.body.oldPassword) != req.user.userarr[0].password) {
        handler(401, "Invalid old passord");
    } else {

        var newPassword = util.encrypt(req.body.newPassword);
        var password = {
            created_by: req.user.userarr[0].user_id,
            newPassword: newPassword,
            user_id: req.user.userarr[0].user_id
        }

        authDal.changeUserPass(password, (err, res) => {
            if (err) {
                handler(500, 'Something went wrong while changing passord');
                app.logger.error(err);
            }
            else {
                handler(200, message.changePassTRUE);
                console.log(req.user);
                let emailobj = Email.setEmail
                    (email,
                    "Confirmation email",
                    "Your password was successfully changed \n\n",
                    "",
                    "\n\nIgnore the message if you didn't request for it")
                emailService.sendMail(emailobj);
            }
        });
    }
}

AuthenticationService.prototype.resetPass = (body, handler) => {
    let util = app.modules.utils.util;
    body.newPassword = util.encrypt(body.newPassword);

    authDal.resetPass(body, (err) => {
        if(err) {
            handler(500, 'Something went wrong while resetting passord');
            app.logger.error("error while resetting user passord caused by    %s", err);
        } else {
            handler(200, message.changePassTRUE);
        }
    });
}

AuthenticationService.prototype.forgotPass = (email, handler) => {
    let util = app.modules.utils.util;
    let userServ = new app.modules.userManagement.userService();
    let userObj = {
        email: email,
        createdOn: util.getCurrentDate()
    }
    let emailHashCode = util.aesEncrypt(JSON.stringify(userObj));
    var tokenExpireOn = util.addDays(util.getCurrentDate(), 10);
    console.log(emailHashCode);
    console.log(tokenExpireOn);
    // let emailOb = {
    //     name: userName,
    //     appurl: util.getConfigValue(tenantId, 'RESET_PASSWORD_URL') + "?oauthToken=" + emailHashCode
    // }
    userServ.getUserBYEmail(email, (err, res) => {
        if (err) {
            app.logger.error("error while reseting password", err);
            handler(500, message.forgotPassFail);
        } else if (_.isEmpty(res)) {
            handler(102, message.emailNotExists)
        } else {
            console.log("res ------"+JSON.stringify(res));
            authDal.saveActivationToken(res[0].user_id, emailHashCode, tokenExpireOn, function (err, res) {
                if (err) {
                    app.logger.error("error while reseting password", err);
                    handler(500, message.forgotPassFail);
                }
                let emailobj = Email.setEmail
                    (email,
                    message.forgotPwdSubject,
                    "To reset your password and complete the process, click on the following link \n\n",
                    `http://localhost:3000/forgotPass/${emailHashCode}`,
                    "\n\nIgnore the message if you didn't request for it")
                emailService.sendMail(emailobj);
                handler(200, message.forgotPwdSucces)
            });
        }
    });

}

AuthenticationService.prototype.isTokenValid = (token, handler) => {
    authDal.isTokenValid(token, (err, res) => {
        if(err) {
            handler(500, "Token invalid or expired");
        } else {
            handler(200, "Valid token")
        }
    })
}

AuthenticationService.prototype.saveNewPassword = (token, password, handler) => {
    authDal.isTokenValid(token, (err, res) => {
        if(err) {
            
            handler(500, err);
        } else {
            authDal.saveNewPassword(res[0].user_id, password, (err, info) => {
                if(err) {
                    handler(500, "Error while saving new password");
                } else {
                    handler(200, "New password saved successfully")
                }
            }) 
        }
    })
    
}

module.exports = AuthenticationService;