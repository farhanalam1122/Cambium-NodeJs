"use strict";
var app = require('@speridian/pankanis-app');
var router = app.expressRouter();
var config = require('config');
var crypto = require('crypto');
var expressFile = require('express-fileupload');
app.express.use(expressFile());
var passport = require('passport');
var restRequest = require('request')
var _ = require('lodash');
var co = require('co');
var foreach = require('co-foreach');
var authService = require('./authenticationService');
var authServ = new authService();
var auth = require('../auth');
var constants = require('../common/constants');

var apiResponse = require('../common/apiresponse')

function savePassportSession(req, res) {
    console.log("in save passport session function");
    var apiResponse = app.modules.common.apiresponse;
    var message = app.modules.props.message;
    req.session.save(function (err) {
        if (err) {
            app.logger.error(`Error in saving session ${err}`);
            res.send(apiResponse.errorResponse(500, message.loginFailed));
            res.status(500);
        } else {
            console.log("session successfully saved");
            console.log("req.user : " + JSON.stringify(req.user));
            app.logger.info(`session saved successfully for user -->`, req.user.user_id);
            /**
             * Temporary fix for authentication will need to remove.
             * Adding connect.sid parameter in response so client site can send auth token for authentication 
             */
            console.log(req.headers);
            var data = { 'connect.sid': req.sessionID };
            data.user = req.user.userarr[0]; 
            console.log("req.user ......................")
            console.log(req.user);

            console.log(app.modules.utils.util.getCurrentDate());

            app.knex('m_login').insert({
                login_date: app.modules.utils.util.getCurrentDate(),
                user_id: req.user.userarr[0].user_id   
            }).where('user_id', req.user.userarr[0].user_id).then(data => {
                console.log(data);
            })
            // {
                // 'user_id': req.user.userarr[0].user_id,
                // 'status': req.user.userarr[0].status,
                // 'name': req.user.userarr[0].name
            // }
            res.send(apiResponse.dataResponse(200, message.loginSuccess, data))
            res.status(200);
        }
    });
}


var passport = require('passport');
var LocalStrategy = require('passport-local').Strategy;


passport.use(new LocalStrategy(function(username, password, done) {
    console.log("inside strategy callback function");
        process.nextTick(function () {
            password = app.modules.utils.util.encrypt(password);
            console.log(password);
            console.log("below password");
            app.knex('m_user')
                .select()
                .where('name', username)
                .andWhere('password', password)
                .limit(1)
                .then(function (userarr) {

                    if (_.isEmpty(userarr[0])) {
                        done({ code: 404, message: 'User not found.' });
                    } else {
                        console.log("userarr inside local strategy : " + JSON.stringify(userarr));
                        var user = new Object();
                        user.userarr = userarr;
                        user.password = password;
                        // validateUserRequest(user, (err, userResult) => {
                        //     if (err)
                        //         done(err);
                        //     else done(null, userResult);
                        // })
                        done(null, user);
                    }


                }).catch(err => {
                    return done(err)
                });
        });
}));

passport.serializeUser(function (userr, done) {
    app.logger.info(`serializeUser ${JSON.stringify(userr)}`);
    done(null, userr);
});

passport.deserializeUser(function (user, done) {

    console.log(user);
    app.knex('m_user')
        .select()
        .where('user_id', user.userarr[0].user_id)
        .then(function (userResult) {
            co(function* () {
                if (_.isEmpty(userResult))
                    return done(null, false);

                return done(null, userResult[0]);
            })
                .catch((err) => {
                    return done(err)
                })
        }).catch(err => {
            return done(err)
        });

});

function saveInDatabase() {
    var knex = app.knex;
    // knex('m_login').insert()
    console.log("req.user ......................")
    console.log(req.user);
}

router.post('/login', 
    // passport.authenticate('portal', { failWithError: true }),
    passport.authenticate('local', { failWithError: true }),
    savePassportSession,
    // saveInDatabase,
    function (err, req, res, next) {
        console.log(req.session);
        console.log("router callback");
        err.code = err.code || err.status;
        res.send(err).status(200);
        console.log("after sending status..");
    }
    // function(req, res, next) {
    //     var knex = app.knex;
    //     console.log(req.body);
    //     knex('m_user').select('*')
    //                   .where('name', req.body.name)
    //                   .andWhere('password', app.modules.utils.util.encrypt(req.body.password))
    //                   .then(function(user) {
    //                       if(user.length != 0){
    //                         res.send({
    //                             "code": 200,
    //                             "message": "Successfull login",
    //                             "data": user
    //                         });
    //                       } else{
    //                         res.send({
    //                             "code": 500,
    //                             "message": "UnSuccessfull login",
    //                             "data": null
    //                         });
    //                       }
    //                     });
    // }
);
    

// passport.authenticate('local'),
// router.post('/login',  function(req, res, next) {
//     console.log("body");
//     console.log(req.body);
//     let apiResponse = app.modules.common.apiresponse;
//     let message = app.modules.props.message;
//     if(auth.checkIfUserExists(req.body)) {

//         res.send(apiResponse.dataResponse(200, message.loginSuccess, {})).status(200);
//         console.log("after send");
//         // res.redirect('/users/' + req.username); 
//     } else {
//         res.send("Unsuccessful");
//     }
// });

router.get('/logout',
 auth.autheticateAny,
 function(req, res, next) {
    
    console.log("inside logout");
    let apiResponse = app.modules.common.apiresponse;
    let message = app.modules.props.message;
    try {
        console.log(req.user);
        req.logout();
        console.log(req.session);
        req.session.destroy(function(err) {
            if(err) {
                console.log(err);
            }
            console.log(req.session);
            res.send(apiResponse.dataResponse(200, message.successfullLogout, {})).status(200);
        });
    } catch (err) {
        app.logger.error(`Error in logout  ${err}`);

        res.send(apiResponse.dataResponse(500, message.logoutFailed, err)).status(500);
    }
});

// router.post('/changePass', function(req, res) {
//     console.log("inside change password function in auth controller...");
//     var pass;
    

//     console.log(req.body.user_id);
//     co(function* () {
//         let res = yield app.knex.select('password').from('m_user').where('user_id', req.body.user_id).returning('*');
//         console.log(res[0].password);
//         pass = res[0].password;
//         console.log(pass);
//         console.log("Old password from table is : " + pass);
//         authServ.changePass(req, pass, (code, mesg) => {
//             let apiResponse = app.modules.common.apiresponse;
//             console.log(apiResponse.dataResponse(code, mesg, null));
//         });
//     }).catch(err => {
//         console.log(err)
//     })
    // console.log(pass);
    // authServ.getOldPasswordById(req.body.user_id, (pass) => {
        
    // })

    


    // console.log("Old password from table is : " + pass);
    // authServ.changePass(req, pass, (code, mesg) => {
    //     let apiResponse = app.modules.common.apiresponse;
    //     res.send(apiResponse.dataResponse(code, mesg, null));
    // });
// });

router.post('/saveBarcode', auth.autheticateAny, function(req, res) {
   console.log(req.body);
   req.body.status = "unused";
   authServ.saveBarcode(req.body, (err, code, mesg, entry) => {
       if(err){
        let response = apiResponse.dataResponse(code, mesg, null);
        res.json(response);
       } else {
           console.log(entry);
        let response = apiResponse.dataResponse(code, mesg, entry);
        res.json(response);
       }
   })
});

router.get('/allBarcodes', auth.autheticateAny, function(req, res) {
    authServ.getAllBarcodes((err, code, mesg, entries) => {
        if(err) {
            let response = apiResponse.dataResponse(code, mesg, null);
            res.json(response);
        } else {
            let response = apiResponse.dataResponse(code, mesg, entries);
            res.json(response);
        }
    })
})

router.post('/changePass', auth.autheticateAny, (req, res) => {
    authServ.changePass(req, (code, mesg) => {
        let apiResponse = app.modules.common.apiresponse;
        if(!res.headersSent)
            res.send(apiResponse.dataResponse(code, mesg, null));
    });
});

router.post('/resetPass', auth.autheticateAny , (req, res) => {
    console.log(req.user);
    // req.body.created_by = req.user.userarr[0].name;
    req.body.created_by = req.user.name;
    authServ.resetPass(req.body, (code, mesg) => {
        let apiResponse = app.modules.common.apiresponse;
        res.send(apiResponse.dataResponse(code, mesg, null));
    })
})

router.post('/forgotPass', (req, res) => {
    console.log(req.body);
    authServ.forgotPass(req.body.email_id, (code, mesg) => {
        let apiResponse = app.modules.common.apiresponse;
        res.send(apiResponse.dataResponse(code, mesg, null)).status(code);
    });

})

router.get('/forgotPass/:token', function(req, res) {
    authServ.isTokenValid(req.params.token, (code, mesg) => {
        let apiResponse = app.modules.common.apiresponse;
        res.send(apiResponse.dataResponse(code, mesg, null)).status(code);
    })
})

router.post('/forgotPass/:token', function(req, res) {
    req.body.newPassword = app.modules.utils.util.encrypt(req.body.newPassword);
    authServ.saveNewPassword(req.params.token, req.body.newPassword, (code, mesg) => {
        console.log(mesg);
        let apiResponse = app.modules.common.apiresponse;
        res.send(apiResponse.dataResponse(code, mesg, null)).status(code);
    })
})

app.express.use('/', router);
app.logger.info('authentication module initialized');