
"use strict";
let app = require('@speridian/pankanis-app');
let co = require('co');
let _ = require('lodash');

function changeUserPass(password, done) {
    co(function* () {
        let util = app.modules.utils.util;

        var passwordLog = yield app.knex('m_password_history')
            .insert({
                password: password.newPassword,
                created_on: util.getCurrentDate(),
                created_by: password.created_by,
                user_id: password.user_id
            });
          
        changeInUser(password.user_id, password.newPassword, (res) => {
            console.log(';;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;');
            console.log(res);
        });
            
        done(null, passwordLog)
    }).catch(err => {
        done(new Error('user password update Failed'), {});
    });
}

function changeInUser(userId, password, done) {
    co(function* () {
        var res = yield app.knex('m_user')
        .where({
            user_id: userId
        })
        .update({
            password: password
        });
        done(res);
    }).catch(err => {
        done(null);
    })
}

function saveBarcode(entry, done) {
    var knex = app.knex;
    co(function* () {
        let res = yield knex('inward').insert(entry).returning('*')
        console.log('**********');
        console.log(res);
        done(null, res);
    }).catch(err => {
        console.log('...........');
        app.logger.error(`errror while saving entry `);
        done(err, null);
    })
}

function getAllBarcodes(done) {
    var knex = app.knex;
    co(function* () {
        let res = yield knex.select().from('inward').returning('*')
        console.log(res)
        done(res)
    }).catch(err => {
        app.logger.error(`errror while fetching entries `)
        done(err)
    })
}

// function changeUserPass(password, done) {
//     co(function* () {
//         let util = app.modules.utils.util;

//         var passwordLog = yield app.knex('m_user_pass_log')
//             .insert({
//                 hash_code: password.hash_code,
//                 created_on: util.getCurrentDate(),
//                 password_status: password.status,
//                 created_by: password.user_id,
//                 user_id: password.user_id
//             });
//         var res = yield app.knex('m_user_logins')
//             .where({
//                 user_id: password.user_id,
//                 login_type: password.login_type
//             })
//             .update({
//                 hash_code: password.hash_code,
//                 pass_expire_on: password.pass_expire_on
//             });
//         done(null, res)
//     }).catch(err => {
//         done(new Error('user password update Failed'), {});
//     });
// }

function resetPass(body, done) {
    co(function* () {
        let util = app.modules.utils.util;
        var res = yield app.knex('m_user')
                           .where('user_id', body.user_id)
                           .update({
                               password: body.newPassword
                           })
        
        var passwordLog = yield app.knex('m_password_history')
                            .insert({
                                password: body.newPassword,
                                created_on: util.getCurrentDate(),
                                created_by: body.created_by,
                                user_id: body.user_id
                            })
        done(null);
    }).catch(err => {
        app.logger.error(`errror while resetting password `)
        done(err)
    })
}

function saveActivationToken(user_id, reset_token, reset_token_expiresat, handler) {
    console.log("...............................................");
    co(function* () {
        let res = yield app.knex('m_login')
            .insert(
            {
                user_id: user_id,
                reset_token_expiresat: reset_token_expiresat,
                reset_token: reset_token
            }
            ).returning('*')
            console.log(res);
        console.log('Updated token')
        handler(null, res)
    }).catch(err => {
        handler(new Error('user password update Failed'), {});
    });
}

function convertDate(date) {
  var yyyy = date.getFullYear().toString();
  var mm = (date.getMonth()+1).toString();
  var dd  = date.getDate().toString();

  var mmChars = mm.split('');
  var ddChars = dd.split('');

  return yyyy + '-' + (mmChars[1]?mm:"0"+mmChars[0]) + '-' + (ddChars[1]?dd:"0"+ddChars[0]);
}

function isTokenValid(token, done) {
    let util = app.modules.utils.util;
    
    co(function* () {
        let expiresat = yield app.knex('m_login')
                                 .select('reset_token_expiresat')
                                 .where('reset_token', token);
        console.log('**************************');
        console.log(expiresat);
        let d = convertDate(expiresat[0].reset_token_expiresat);
        console.log(d > convertDate(new Date()));
        console.log('//////////////');
        console.log(convertDate(new Date()));
        if(d > convertDate(new Date()) ) {
            co(function* () {
                // console.log('***********')
                // console.log(convertDate(new Date()));
                // console.log('............');
                
                let res = yield app.knex('m_login')
                                   .select('user_id')
                                   .where('reset_token', token);
                console.log('...........');
                console.log(res);
                done(null, res);
            }).catch(err => {
                done(err, null);    
            });
        } else {
            done("err", null);
        }
    }).catch(err => {
        done(err, null);
    })    
}

function saveNewPassword(userId, password, done) {
    co(function* () {

        co(function* () {
            let r = yield app.knex('m_password_history')
                        .insert({
                            user_id: userId,
                            password: password,
                            created_by: userId,
                            created_on: app.modules.utils.util.getCurrentDate()
                        })
                        .where('user_id', userId)
            console.log(r);
        }).catch(err => {
            console.log(err);
        });
        

        let res = yield app.knex('m_user')
                           .update({
                               password: password
                           })
                           .where('user_id', userId)
        done(null, res);
    }).catch(err => {
        done(err, null);
    })
}

module.exports = {
    changeUserPass, saveBarcode, getAllBarcodes, resetPass, saveActivationToken, isTokenValid, saveNewPassword
}