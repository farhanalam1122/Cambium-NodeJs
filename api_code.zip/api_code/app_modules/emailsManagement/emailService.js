"use strict";
var path = require('path');
const EmailTemplate = require('email-templates').EmailTemplate;
var config = require('config');
var emailconfig = config.maildetails;
var basetemplatesdir = config.emailTemplateBaseDir;
var templatesDir = path.resolve(basetemplatesdir);
var app = require('@speridian/pankanis-app');
const nodemailer = require('nodemailer');
const wellknown = require('nodemailer-wellknown');
var async = require('async');

module.exports.sendMail = function (emailobject) {
	try {
		// let urlConfig;
		// let options;
		// let mailer;
		// let maildetails = emailobject.mailDetails;
		// if (!maildetails) {
		// 	maildetails = emailconfig;
		// }
		// maildetails.mailuser = maildetails.mailuser.replace(/\s/g,'');
		
		// var temPathToTenant = path.join(templatesDir, emailobject.name.tenant_id.toString());
		
		// //appending logourl and tenant name to emailobject.name.customParams
		// emailobject.name.customParams.TenantName = emailobject.name.tenant_info.name;
		// emailobject.name.customParams.LogoUrl = path.join(temPathToTenant, "/imgs/logo.png");
		// var temPath = path.join(temPathToTenant, emailobject.templateCode);
		// console.log(temPath);
		// var template = new EmailTemplate(temPath);

		// // template.dirname=templatePath;
		// template.render(emailobject, function (err, results) {
		// 	if (err) {
		// 		return app.logger.error(`Error while temaplate genartion mail email object : ${JSON.stringify(emailobject)} \n caused by error : ${err.stack} `);
		// 	}
		// 	//Prepare nodemailer transport object
		// 	app.logger.info(`Mail template --${results.html}`);
		console.log('*********');
		console.log(emailobject);
			var transport = nodemailer.createTransport({
				service: 'Gmail',
				host: "smtp.gmail.com",
				port: 587,
        		secure: false, 
				auth: {
					type: "login",
					user: 'deletematkar@gmail.com',
					// pass: process.env.GMAILPW,
					pass: 'backstage@123'
				}
			})
			transport.sendMail({
				from: 'bestpjshakespeare@gmail.com',
				to: emailobject.to,
				// to: 'bestpjshakespeare@gmail.com',
				subject: emailobject.subject,
				// html: results.html,
				html: `<b>Done</b> <br/><br/>
						<p>${emailobject.name}</p>
						<a href="${emailobject.body}">${emailobject.body}</a>
						<p>${emailobject.footer}</p>`,
				// attachments: emailobject.attachments,
				// cc: emailobject.cc,
				text: 'Received the email'
			}, function (err, responseStatus) {
				if (err) {
					console.log(err);
					return app.logger.error(`Error while sending mail email object : ${JSON.stringify(emailobject)} \n caused by error : ${err} `);
				}
				else {
					app.logger.info(`Email sent to  ${emailobject.to} from : ${maildetails.mailuser} : with status : ${responseStatus.message}`)
				}
			})
		// })
		
	} catch (err) {
		app.logger.error(`---------------errror while sending notification caused by error ${err.message}`)
	}
};

