"use strict";
var app = require('@speridian/pankanis-app');

var util = require('../utils/util');
class Email {
  constructor(to, subject, name, body, footer, mailDetails) {
    // this.from = from;
    this.to = to;
    this.subject = subject;
    // this.templateCode = templateCode;
    this.name = name;
    this.body = body;
    this.footer = footer;
    this.mailDetails = mailDetails;
  }
}


module.exports = {
  setEmail: function (to, subject, name, body, footer) {

    // var emailDetials = JSON.parse(util.getConfigValue(tenant_id, 'EMAIL_DETAILS'));
    // name.customParams = emailDetials.customParams;
    // name.customParams.CurrentYear = new Date().getUTCFullYear();
    var emailDetials = {

    }
    return new Email(
      to,
      subject,
      // templateCode,
      name,
      body,
      footer,
      emailDetials
    );
  }
}