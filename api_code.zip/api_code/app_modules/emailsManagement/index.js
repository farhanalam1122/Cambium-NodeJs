var email =require('./email') ;
var emailService = require('./emailService')

module.exports={
    createEmail :email.setEmail ,
    sendEmail :emailService.sendMail
}