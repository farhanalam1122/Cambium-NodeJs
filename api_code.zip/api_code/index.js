console.log(process.cwd());

const app = require('@speridian/pankanis-app');

const config = require('config');
const path = require('path');


var serveStatic = require('serve-static');

app.express.use(serveStatic('portal', { 'index': ['index.html', 'index.htm'] }))

app.start (3002);
app.express.get('/', (req, res) => res.send('Hello World!'))

//app.express.listen(3000, () => console.log('App listening on port 3000!'))
