export default

    {
      "id": 1,
      "product-name": "Fastrack Party Analog Black Dial Men's Watch - NE1474SM02",
      "documentTypes": ["doctype1","doctype2","doctype3"]
    }
  